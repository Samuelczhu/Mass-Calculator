package com.example.administrator;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button cylinder = (Button) findViewById(R.id.cylinder);
        cylinder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CylinderActivity.class);
                startActivity(intent);
            }
        });

        Button hollowCylinder = (Button) findViewById(R.id.hollow_cylinder);
        hollowCylinder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, HollowCylinderActivity.class);
                startActivity(intent);
            }
        });
    }
}
