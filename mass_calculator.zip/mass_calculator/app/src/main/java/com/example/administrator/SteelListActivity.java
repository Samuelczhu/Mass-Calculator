package com.example.administrator;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class SteelListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_steel_list);

        setTitle(getString(R.string.list_text));

        ListView listView = (ListView) findViewById(R.id.list);

        final SteelAdapter steelAdapter = new SteelAdapter(this, new ArrayList<Steel>());
        listView.setAdapter(steelAdapter);

        //producing a bunch of data
        for (int i=421;i<=426;i++) {
            if (i%2 == 1) { //钢材
                steelAdapter.add(new Steel(i+" "+getString(R.string.gang_cai), 7.85, "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1528286832340&di=e36366b1a1d78a956182ef8a6972cc08&imgtype=0&src=http%3A%2F%2Fimg3.jqw.com%2F2017%2F03%2F15%2F1758025%2Fproduct%2Fb201703161127148024.jpg"));
            } else { //碳钢
                steelAdapter.add(new Steel(i+" "+getString(R.string.tan_gang), 7.85, "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1528286936741&di=2c17b870e0f10d5d9b333cd00d668675&imgtype=0&src=http%3A%2F%2Fbmp.skxox.com%2F201606%2F03%2Fmjgy123.152637.jpg"));
            }
        }

        for (int i=427;i<=429;i++) {//工业纯铁
            steelAdapter.add(new Steel(i+" "+getString(R.string.gong_ye_cun_tie), 7.87, "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1528287179194&di=e09de457e9cdb3efd1f24d0129400637&imgtype=jpg&src=http%3A%2F%2Fimg0.imgtn.bdimg.com%2Fit%2Fu%3D314539345%2C3318067259%26fm%3D214%26gp%3D0.jpg"));
        }

        //合金钢
        steelAdapter.add(new Steel(430+" "+getString(R.string.he_jin_gang), 7.9, "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1528287262478&di=f2aaa1a0946242ae868a33c3fa440914&imgtype=0&src=http%3A%2F%2Fimg1.windmsn.com%2Fb%2F2%2F242%2F24299%2F2429908.jpg"));

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Steel currentSteel = steelAdapter.getItem(position);
                String queryURI = "http://www.baidu.com/s?wd="+currentSteel.getName();
                Uri webUri = Uri.parse(queryURI);
                Intent intent = new Intent(Intent.ACTION_VIEW, webUri);
                startActivity(intent);
            }
        });
    }
}
