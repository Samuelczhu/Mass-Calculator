package com.example.administrator;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class CylinderActivity extends AppCompatActivity {

    EditText density_input;
    EditText diameter_input;
    EditText length_input;
    Button calculate;
    TextView answerText;
    ImageView infoImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cylinder);

        //find view by ids
        density_input = (EditText) findViewById(R.id.density_input);
        diameter_input = (EditText) findViewById(R.id.diameter_input);
        length_input = (EditText) findViewById(R.id.length_input);
        calculate = (Button) findViewById(R.id.calculate);
        answerText = (TextView) findViewById(R.id.answer);

        //onclick
        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    getAnswer();
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), getString(R.string.impossible), Toast.LENGTH_LONG).show();
                }
            }
        });

        //icon onclick
        infoImage = (ImageView) findViewById(R.id.info_image);
        infoImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CylinderActivity.this, SteelListActivity.class);
                startActivity(intent);
            }
        });
    }

    private void getAnswer() {
        double density = Double.valueOf(density_input.getText().toString());
        double diameter = Double.valueOf(diameter_input.getText().toString());
        String lengthString = length_input.getText().toString();

        String ans = "";
        DecimalFormat decimalFormat = new DecimalFormat("#0.0000");

        if (lengthString.equals("") || lengthString == null) { // empty length input
            ans = decimalFormat.format(calculateAnswer(density,diameter)) + " kg/m";
        } else { // all input have text
            double length = Double.valueOf(lengthString);
            ans = decimalFormat.format(calculateAnswer(density,diameter,length)) + " kg";
        }
        answerText.setText(ans);
    }

    private double calculateAnswer(double density, double diameter) {
        density = density*Math.pow(100,3)/1000; //convert g/cm3 to kg/m3
        double r = (diameter/1000)/2; //convert unit mm to m
        return Math.PI * Math.pow(r,2)*density; // unit: kg/m
    }
    private double calculateAnswer(double density,double diameter, double length) {
        density = density*Math.pow(100,3)/1000; //convert g/cm3 to kg/m3
        double r = (diameter/1000)/2; //convert unit mm to m
        return Math.PI * Math.pow(r,2)*length*density; //unit: kg
    }
}
