package com.example.administrator;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class SteelAdapter extends ArrayAdapter<Steel> {

    public SteelAdapter(Context context, List<Steel> steels) {
        super(context, 0, steels);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }

        //getting the current steel object
        Steel currentSteel = getItem(position);

        //setting the views
        TextView name = (TextView) listItemView.findViewById(R.id.name_text);
        name.setText(currentSteel.getName());
        TextView density = (TextView) listItemView.findViewById(R.id.density_text);
        density.setText(currentSteel.getDensity() + " g/cm^3");

        //setting the image
        ImageView imageView = (ImageView) listItemView.findViewById(R.id.steel_image);
        Picasso.get().load(currentSteel.getImageUrl()).resize(100,100).centerCrop().into(imageView);

        return listItemView;
    }
}
