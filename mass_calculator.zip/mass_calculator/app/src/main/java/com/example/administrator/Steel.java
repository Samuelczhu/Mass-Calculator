package com.example.administrator;

public class Steel {

    private String name;
    private double density;
    private String imageUrl;

    public Steel(String name, double density, String imageUrl) {
        this.name = name;
        this.density = density;
        this.imageUrl = imageUrl;
    }

    public String getName() {
        return name;
    }

    public double getDensity() {
        return density;
    }

    public String getImageUrl() {
        return imageUrl;
    }
}
